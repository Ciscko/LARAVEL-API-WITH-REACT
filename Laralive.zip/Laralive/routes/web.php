<?php

use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::prefix('/admin')->namespace('Admin')->name('admin.')->group(function(){
    Route::namespace('Auth')->group(function(){
           Route::get('/login', 'LoginController@showLoginForm')->name('login');
           Route::post('/login', 'LoginController@login');
           Route::post('/logout', 'LoginController@logout')->name('logout');
           Route::get('/register', 'RegisterController@showRegisterForm')->name('register');
           Route::post('/register', 'RegisterController@register');
    });

    Route::get('/products', 'ProductsController@index')->name('products');
    Route::get('/products/view/{product}', 'ProductsController@view')->name('products.view');
    Route::get('/products/create', 'ProductsController@create')->name('products.create');
    Route::get('/products/{product}/edit', 'ProductsController@edit')->name('products.edit');
    Route::put('/products/{id}', 'ProductsController@update')->name('products.update');
    Route::post('/products', 'ProductsController@store')->name('products.store');
    Route::delete('/products/{id}', 'ProductsController@destroy')->name('products.delete');
});

Route::namespace('Auth')->group(function(){
    Route::get('/login', 'LoginController@showLoginForm')->name('login');
    Route::post('/login', 'LoginController@login');
    Route::post('/logout', 'LoginController@logout')->name('logout');
    Route::get('/register', 'RegisterController@showRegisterForm')->name('register');
    Route::post('/register', 'RegisterController@register');
    //others 
});

Route::prefix('/author')->namespace('Author')->group(function(){
    Route::get('', 'AuthorController@index')->name('author.index');
    Route::get('/create', 'RegisterController@showRegisterForm')->name('author.create');
    Route::post('/register', 'RegisterController@register')->name('author.register');
    Route::get('/login', 'LoginController@showLoginForm')->name('author.login');
    Route::post('/login', 'LoginController@login')->name('author.store');
});

Route::resource('/posts', 'PostsController');

Route::resource('/comments', 'CommentController');
Route::resource('/readers', 'ReaderController');


Route::get('/home', 'HomeController@index')->name('home')->middleware('auth:web');
Route::get('/', function () {
    return view('welcome');
});

Route::get('/api', 'SalesController@load');



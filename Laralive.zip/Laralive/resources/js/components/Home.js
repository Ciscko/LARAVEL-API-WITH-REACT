import React from 'react'
import axios from 'axios'
import { useSpring, animated } from 'react-spring'

const Home = () => {
    const [data, setData] = React.useState({ products: [] })
    const [total, setTotal] = React.useState('')
    const [page, setPage] = React.useState()
    const [lastPage, setLast] = React.useState()
    const [url, setUrl] = React.useState(`http://127.0.0.1:8000/admin/products`)
    const [next, setNext] = React.useState('')
    const [prev, setPrev] = React.useState('')
    const [paginate, setPaginate] = React.useState(2)
    const [pageCount, setPageCount] = React.useState(1)
    const gotopage = React.useRef(null)
    const [searchValue, setSearchValue] = React.useState('')
    let myurl = `http://127.0.0.1:8000/admin/products`
    const fadeAnime = useSpring({
        from: { opacity: 0 },
        to: { opacity: 1 }
    })

    React.useEffect(() => {
        const fetchProducts = () => {
            axios.get(url)
                .then(res => {
                    setData({ products: [...res.data.data] })
                    setTotal(res.data.total)
                    setPage(res.data.current_page)
                    setNext(`${res.data.next_page_url}&per_page=${paginate}`)
                    setPrev(`${res.data.prev_page_url}&per_page=${paginate}`)
                    setLast(res.data.last_page)
                    setPageCount(Math.ceil(total / paginate))
                    
                }).catch(e => console.log(e))
        }
        fetchProducts();
    }, [url, next, prev, paginate, page])

    function show(event) {
        let show = event.target.value;
        setPaginate(show)
        let uri = `${myurl}?per_page=${show}&search=${searchValue}`
        setUrl(uri)
    }

    function handleSearch(event){
        let searchVal = event.target.value
        setSearchValue(searchVal)
        let uri = `${myurl}?per_page=${paginate}&search=${searchVal}`
        setUrl(uri)
    }

    function goTo(event) {
        let pageNumber = Math.min(event.target.value, pageCount)
        setPage(pageNumber)
        let uri = `${myurl}?page=${pageNumber}&per_page=${paginate}`
        setUrl(uri)
    }

    return (
        <div className="container">
            <div className="row">
                <div className="col-lg-4">
                    Show <select className="pager" name="show" onChange={(e) => show(e)}>
                        <option value="2">2</option>
                        <option value="1">1</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value={total}>All</option>
                    </select>
                Out of {total}
                </div>
                <div className="col-lg-4"><br></br></div>
                <div className="col-lg-4">
                    <input className="form-control" onChange={(e) => handleSearch(e)}  placeholder="Type to search" />
                </div>
            </div>
            <hr></hr>
            <div className="">
                {
                    <ul style={fadeAnime} className="list-group">
                        <li style={fadeAnime} className="list-group-item"><h4>All Products</h4></li>
                        {
                            data.products.length > 0 ?
                                data.products.map((product, index) => (
                                    <li style={fadeAnime} className="list-group-item" key={index}>{product.name}</li>
                                ))
                                :
                                <li style={fadeAnime} className="list-group-item"> No available Products! </li>
                        }
                    </ul>
                }
            </div>
            <hr></hr>
                <div className="container bottom-pager">
                    <div className="row">
                        <div className="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <button disabled={page !== 1 ? false : true} onClick={() => setUrl(prev)} className="btn btn-sm btn-dark">Prev</button>
                            <button disabled={page !== lastPage ? false : true} onClick={() => { setUrl(next) }} className="btn btn-sm btn-success">Next</button>
                        </div>
                       
                        <div className="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                            <span className="">Page <input  ref={gotopage} type="number" className="pager" name="goto" onChange={(e) => goTo(e)} /> of {pageCount} pages</span>
                        </div>
                    </div>
                </div>
        </div>
    )
}

export default Home
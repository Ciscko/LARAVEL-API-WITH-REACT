import React from 'react';
import ReactDOM from 'react-dom';
import Home from './Home'

const Main =  () => {
    return (
        <Home/>
    );
}


ReactDOM.render(<Main/>, document.getElementById('main'));


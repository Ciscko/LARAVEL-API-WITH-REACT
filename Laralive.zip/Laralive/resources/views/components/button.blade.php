<div>
    <!-- Well begun is half done. - Aristotle -->
    <button {{ $attributes }} onclick="show()"> {{ $text }}</button>
</div>



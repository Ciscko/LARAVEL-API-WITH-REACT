<div>
    <!-- It is not the man who has too little, but the man who craves more, that is poor. - Seneca -->
    {{-- {{ Route::currentRouteName() }} --}}
    <div class="container">
        @if(Route::currentRouteName() != 'admin.products.create')
            <a class="btn btn-sm btn-info" href="{{ route('admin.products.create') }}">Add Product</a>
        @endif
         @if(Route::currentRouteName() != 'admin.products')
        <a class="btn btn-sm btn-secondary" href="{{ route('admin.products') }}">List Products</a>
         @endif
        <hr>
    </div>
    
</div>
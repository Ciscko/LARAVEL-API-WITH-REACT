@extends('layouts.app')
@section('content')
<div class="container">
    <form action="{{ route('readers.store') }}" method="post">
            @csrf
            <label for="name">Name</label>
            <input id="name" placeholder="Enter Name Here" type="text" name="name" class="form-control" />
            @error('name'))
            <div class="alert alert-danger">{{ $message }}</div>
            @enderror
            <br>
            <label for="email">Email</label>
            <input id="email" placeholder="Enter Email Here" type="text" name="email" class="form-control" />
            @error('email'))
            <div class="alert alert-danger">{{ $message }}</div>
            @enderror
            <br>
        <button type="submit" class="btn btn-info">Save</button>
    </form>
</div>
@endsection

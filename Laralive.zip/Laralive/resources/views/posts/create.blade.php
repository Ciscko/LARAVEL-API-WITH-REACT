@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Create Posts</h3>
</div>
<div class="container">
    <form action={{ route('posts.store') }} method="post">
        @csrf
        <div class="">
            <label for="title">Title</label>
            <input id="title" type="text" name="title" class="form-control" />
            @error('title')
                <div class=" alert alert-danger">{{$message}} <button class="close" data-dismiss="alert" role>&times;</button></div>
            @enderror
        </div>
        <div class="">
            <label for="slug">Slug</label>
            <input class="form-control" id="slug" name="slug" />
            @error('slug')
                <div class=" alert alert-danger">{{$message}} <button class="close" data-dismiss="alert" role>&times;</button> </div>
            @enderror
        </div>
        <div class="">
            <label for="body">Body</label>
            <textarea id="body" name="body" class="form-control"></textarea>
            @error('body')
                <div class="alert alert-danger">{{$message}} <button class="close" data-dismiss="alert" role>&times;</button></div>
            @enderror
        </div>
        <br>
        <input type="submit" class="btn btn-info" value="Save" />
    </form>
</div>
@endsection

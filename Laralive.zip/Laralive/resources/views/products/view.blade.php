@extends('layouts.app')
@section('content')
<x-products-nav/>
<div class="container">
    <div class="row">
            <img style="max-width:30%; max-height:20%;" class="img img-responsive img-thumbnail" src="{{asset($product->image)}}"/>
    </div>
</div>
    <div class="container"> {{$product->name}} </div>
@endsection
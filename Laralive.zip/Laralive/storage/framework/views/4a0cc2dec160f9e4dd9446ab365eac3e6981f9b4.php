<div>
    <!-- It is not the man who has too little, but the man who craves more, that is poor. - Seneca -->
    
    <div class="container">
        <?php if(Route::currentRouteName() != 'admin.products.create'): ?>
            <a class="btn btn-sm btn-info" href="<?php echo e(route('admin.products.create')); ?>">Add Product</a>
        <?php endif; ?>
         <?php if(Route::currentRouteName() != 'admin.products'): ?>
        <a class="btn btn-sm btn-secondary" href="<?php echo e(route('admin.products')); ?>">List Products</a>
         <?php endif; ?>
        <hr>
    </div>
    
</div><?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/components/products-nav.blade.php ENDPATH**/ ?>
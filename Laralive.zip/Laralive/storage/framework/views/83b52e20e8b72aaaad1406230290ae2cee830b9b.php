<div>
    Hello guys, please include me in your vishwaas!
</div><?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/greetings.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
 <?php if (isset($component)) { $__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ProductsNav::class, []); ?>
<?php $component->withName('products-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f)): ?>
<?php $component = $__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f; ?>
<?php unset($__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<div class="container">
    <h3>All Products</h3>
    <?php if(count($products) > 0): ?>
    <ol class="list-group list-group-flush">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item">
        <img style="width:50px; height:40px;"
         src="<?php echo e(asset($product->image)); ?>"> <?php echo e($product->name); ?>

        <span class="float-right">
         <a href="<?php echo e(route('admin.products.edit', ['product' => $product->id])); ?>"
          class="btn btn-sm btn-primary"> Edit </a> <a class="btn btn-sm btn-success"
           href="<?php echo e(route('admin.products.view', ['product' => $product->id])); ?>"> View </a>
            <button class="btn btn-sm btn-danger" onclick="document.querySelector('.delete-form').submit();"> Delete </button></span></li>
        <form class="delete-form" action="<?php echo e(route('admin.products.delete', ['id' => $product->id ])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
</form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </ol>
    <?php else: ?>
    <p> No products are available for now ! </p>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>



































<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/products/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
 <?php if (isset($component)) { $__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ProductsNav::class, []); ?>
<?php $component->withName('products-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f)): ?>
<?php $component = $__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f; ?>
<?php unset($__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<div class="container">
    <div class="row">
            <img style="max-width:30%; max-height:20%;" class="img img-responsive img-thumbnail" src="<?php echo e(asset($product->image)); ?>"/>
    </div>
</div>
    <div class="container"> <?php echo e($product->name); ?> </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/products/view.blade.php ENDPATH**/ ?>
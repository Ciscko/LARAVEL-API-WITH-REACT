<?php $__env->startSection('content'); ?>
 <?php if (isset($component)) { $__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ProductsNav::class, []); ?>
<?php $component->withName('products-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f)): ?>
<?php $component = $__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f; ?>
<?php unset($__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<div class="container">
    <h3> Create Product</h3>
     <form action="<?php echo e(route('admin.products.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if($errors->any()): ?>
        
        <?php endif; ?>
        <div>
            <input type="text" name="name" class="form-control" />
          
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label for="image">Image</label>
            <input type="file" name='image' class="form-control"/>
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
        <br>
            <input type="submit" value="Submit" class="btn btn-success"/>
        </div>
        <div>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="alert danger"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </form>
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/products/create.blade.php ENDPATH**/ ?>
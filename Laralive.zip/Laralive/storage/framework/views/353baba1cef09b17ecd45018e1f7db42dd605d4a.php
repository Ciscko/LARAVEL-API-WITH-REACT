<?php $__env->startSection('content'); ?>
 <?php if (isset($component)) { $__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ProductsNav::class, []); ?>
<?php $component->withName('products-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f)): ?>
<?php $component = $__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f; ?>
<?php unset($__componentOriginal5e404c3f606a6657805bb3f15db0f79aa08ddb5f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<div class="container">
    <h3> Edit Product </h3>
     <form action="<?php echo e(route('admin.products.update', ['id' => $product->id])); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div>
            <input type="text" name="name" class="form-control" value="<?php echo e($product->name); ?>"/>
        </div>
        <div>
         <div>
            <label for="image">Image</label>
            <input type="file" name='image' class="form-control"/>
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>
            <input type="submit" value="Update" class="btn btn-info"/>
        </div>
    </form>
</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/products/edit.blade.php ENDPATH**/ ?>
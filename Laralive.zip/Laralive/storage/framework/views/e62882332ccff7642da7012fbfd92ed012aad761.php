<div <?php echo e($attributes); ?>>
   <?php echo e($message); ?><br>
   <?php echo e($slot); ?>

    <!-- Let all your things have their places; let each part of your business have its time. - Benjamin Franklin -->
</div><?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/components/navbar-component.blade.php ENDPATH**/ ?>
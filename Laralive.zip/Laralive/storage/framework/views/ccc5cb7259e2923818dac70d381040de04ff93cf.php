<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Create Posts</h3>
</div>
<div class="container">
    <form action=<?php echo e(route('posts.store')); ?> method="post">
        <?php echo csrf_field(); ?>
        <div class="">
            <label for="title">Title</label>
            <input id="title" type="text" name="title" class="form-control" />
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class=" alert alert-danger"><?php echo e($message); ?> <button class="close" data-dismiss="alert" role>&times;</button></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="">
            <label for="slug">Slug</label>
            <input class="form-control" id="slug" name="slug" />
            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class=" alert alert-danger"><?php echo e($message); ?> <button class="close" data-dismiss="alert" role>&times;</button> </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="">
            <label for="body">Body</label>
            <textarea id="body" name="body" class="form-control"></textarea>
            <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?> <button class="close" data-dismiss="alert" role>&times;</button></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>
        <input type="submit" class="btn btn-info" value="Save" />
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/Mbucha.co.ke/public_html/Laralive/resources/views/posts/create.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers\Author;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
//use Auth;

class LoginController extends Controller
{
    public function __construct(){
        //$this->middleware('guest:author');
    }

    public function showLoginForm(){
        return view('auth.login', ['title' => 'Author Login', 'formActionUrl' => 'author.store']);
    }

    public function login(Request $request){
        $request->validate([
            'email' => 'required|email|min:4',
            'password' => 'required|string|min:4'
        ]);

        if(Auth::guard('author')->attempt($request->only('email', 'password') , $request->filled('remember'))){
                return redirect()->intended();
        }
        return back()->withInput();
    }
    
}

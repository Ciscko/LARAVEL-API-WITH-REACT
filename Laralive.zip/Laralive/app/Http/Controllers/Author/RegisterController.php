<?php

namespace App\Http\Controllers\Author;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Author;
use Illuminate\Http\Request;

use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller{
    public function __construct(){
        //$this->middleware('guest:author');
    }

    public function showRegisterForm(){
        return view('auth.register', ['title' => 'Register Post Author', 'formUrl' => 'author.register']);
    }

    public function register(Request $request){
        $request->validate([
                'name' => 'required|string',
                'email' => 'required|email|min:4|unique:authors',
                'password' => 'required|confirmed',
                ]);
                
            Author::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password)
            ]);
        return redirect()->route('authors.index');
    }


}
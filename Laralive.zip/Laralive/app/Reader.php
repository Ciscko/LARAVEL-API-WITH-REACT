<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reader extends Model
{ 
    protected $fillable = ['name', 'email'];

    public function newsmail(){
        return $this->hasOne('App\NewsMail');
    }

    public function comments(){
        return $this->hasMany('App\Comment');
    }

}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NewsMail extends Model
{
    protected $fillable=['reader_id'];

    public function reader(){
        return $this->belongsTo('App\Reader');
    }
}
